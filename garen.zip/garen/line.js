function Line(x1,y1,x2,y2,strk) { // lines constructor
  this.x1 = x1;
  this.y1 = y1;
  this.x2 = x2;
  this.y2 = y2;
  this.s = strk;
  
  this.draw = function() { // draws the lines. nice, right?
  push();
  strokeWeight(linew);
  stroke(this.s);
  line(this.x1,this.y1,this.x2,this.y2);
  pop(); }
}