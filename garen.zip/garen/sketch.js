var lines = [];
var cronch = []; // the dots that pac eats.
var pac; //EVERYTHING IS 20 WIDE AND THAT'S FINAL
var score = 0; // the.... score.

var tg // the variables for the lines.
var lg
var bg
var rg
var mg

var to
var lo
var ro
var bo

var lc
var tc
var bc

var la
var ra
var ma
var ta

var tt
var mt

var ts
var ls
var ms
var rs
var bs

var lw1
var lw2
var lw3

var bw
var rw
var tw

var mb
var rb
var trb

var w1
var w2
var w3
var w4
var w5

var linew = 16; // stroke weight for the lines.

var oD = 20

var o1
var o2
var o3
var o4
var o5
var o6
var o7
var o8
var o9
var o10
var o11
var o12
var o13
var o14
var o15
var o16

var o18
var o19
var o20
var o21
var o22

var o23
var o24
var o25
var o26
var o27


function setup() {
  createCanvas(400, 400);
  pac = new Pac(100,100,20);
  
  tg = new Line(80,60,160,60,'purple'); // making all of the variables into lines.
  lg = new Line(80,60,80,140,'purple');
  bg = new Line(80,140,160,140,'purple');
  rg = new Line(160,100,160,140,'purple');
  mg = new Line(120,100,160,100,'purple');
  
  to = new Line(200,60,280,60,'purple');
	lo = new Line(200,60,200,140,'purple');
	ro = new Line(280,60,280,140,'purple');
	bo = new Line(200,140,280,140,'purple');

	lc = new Line(60,200,60,240,'purple');
	tc = new Line(60,200,100,200,'purple');
	bc = new Line(60,240,100,240,'purple');

	la = new Line(120,200,120,240,'purple');
	ra = new Line(160,200,160,240,'purple');
	ma = new Line(120,220,160,220,'purple');
  ta = new Line(120,200,160,200,'purple');
  
  tt = new Line(200,200,240,200,'purple');
	mt = new Line(220,200,220,240,'purple');
  
	ts = new Line(260,200,300,200,'purple');
	ls = new Line(260,200,260,220,'purple');
	ms = new Line(260,220,300,220,'purple');
	rs = new Line(300,220,300,240,'purple');
	bs = new Line(260,240,300,240,'purple');

	lw1 = new Line(40,20,40,160,'black');
	lw2 = new Line(20,160,40,160,'black');
	lw3 = new Line(20,160,20,360,'black');
  
	bw = new Line(20,360,380,360,'black');
	rw = new Line(380,20,380,360,'black');
	tw = new Line(40,20,380,20,'black');
  
	mb = new Line(60,280,300,280,'black');
	rb = new Line(340,120,340,280,'black');
	trb = new Line(340,60,340,80,'black');
  
	w1 = new Line(60,320,100,320,'black');
	w2 = new Line(60,280,60,320,'black');
	w3 = new Line(200,320,200,360,'black');
	w4 = new Line(140,320,260,320,'black');
	w5 = new Line(300,320,340,320,'black');
  
  lines = [tg,lg,bg,rg,mg,to,lo,ro,bo,lc,tc,bc,la,ra,ma,ta,tt,mt,
             ts,ls,ms,rs,bs,lw1,lw2,lw3,bw,rw,tw,mb,rb,trb,w1,w2,
             w3,w4,w5]; // array with all of the lines in it.
  
  o1 = new Orb(60,40,oD);
	o2  = new Orb(80,40,oD);
	o3 = new Orb(100,40,oD);
	o4 = new Orb(120,40,oD);
	o5 = new Orb(140,40,oD);
	o6 = new Orb(160,40,oD);
	o7 = new Orb(180,40,oD);
	o8 = new Orb(200,40,oD);
	o9 = new Orb(220,40,oD);
	o10 = new Orb(240,40,oD);
	o11 = new Orb(260,40,oD);
	o12 = new Orb(280,40,oD);
	o13 = new Orb(300,40,oD);
  o14 = new Orb(320,40,oD);
  o15 = new Orb(340,40,oD);
  o16 = new Orb(360,40,oD);
  
  o18 = new Orb(60,60,oD);
	o19 = new Orb(180,60,oD);
	o20 = new Orb(300,60,oD);
	o21 = new Orb(320,60,oD);
	o22 = new Orb(360,60,oD);
  
  o23 = new Orb(60,80,oD);
	o24 = new Orb(180,80,oD);
	o25 = new Orb(300,80,oD);
	o26 = new Orb(320,80,oD);
	o27 = new Orb(360,80,oD);
  
}

function draw() {
  background(220);
  pac.display();
  pac.update();
  
  for (i=0; i<20; i++) { // draws the lines in the background.
    line(i*20,0,i*20,400);
    line(0,i*20,400,i*20); }
  
  tg.draw(); // these are all of the lines.
  lg.draw();
  bg.draw();
  rg.draw();
  mg.draw();
  
  to.draw();
	lo.draw();
	ro.draw();
	bo.draw();
  
	lc.draw();
  tc.draw();
	bc.draw();
  
	la.draw();
	ra.draw();
	ma.draw();
	ta.draw();
  
  tt.draw();
	mt.draw();
  
	ts.draw();
	ls.draw();
	ms.draw();
	rs.draw();
	bs.draw();
  
	lw1.draw();
	lw2.draw();
	lw3.draw();
  
	bw.draw();
	rw.draw();
	tw.draw();
  
	mb.draw();
	rb.draw();
	trb.draw();
  
	w1.draw();
	w2.draw();
	w3.draw();
	w4.draw();
	w5.draw();
  
  o1.draw();
  o2.draw();
	o3.draw();
	o4.draw();
  o5.draw();
	o6.draw();
	o7.draw();
	o8.draw();
	o9.draw();
	o10.draw();
	o11.draw();
	o12.draw();
	o13.draw();
  o14.draw();
  o15.draw();
  o16.draw();
  
  o18.draw();
	o19.draw();
	o20.draw();
	o21.draw();
	o22.draw();
  
  o23.draw();
  o24.draw();
	o25.draw();
	o26.draw();
	o27.draw();
  
  stroke('black');
  fill('black');
  textSize(20);
  text("SCORE : " + score,180,400); // score, obviously
}

function Orb(x,y,d) {
  this.x = x;
  this.y = y;
  this.d = d;
  
  this.draw = function() {
    fill('orange');
    ellipse(this.x,this.y,this.d); }
}