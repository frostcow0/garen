function Pac(x,y,diameter) { // pac the man himself, and his constructor
  this.x = x;
  this.y = y;
  this.d = diameter;
  this.speed=1;
  this.dir=0;
  // this.xr = this.x+this.d+linew;
  // this.xl = this.x-this.d-linew;
  // this.yb = this.y+this.d+linew;
  // this.yt = this.y-this.d-linew; 
  
  this.display = function() {
    fill('yellow');
    ellipse(this.x,this.y,this.d); }

	this.update = function() { //1 is UP && 2 is LEFT && 3 is RIGHT && 4 is DOWN
    if (keyIsDown(UP_ARROW))
      this.dir=1;
    if (keyIsDown(LEFT_ARROW))
      this.dir=2; 
    if (keyIsDown(RIGHT_ARROW))
      this.dir=3;
    if (keyIsDown(DOWN_ARROW))
      this.dir=4;
    if (this.dir==1)
      if (this.collision(this.x,this.y-this.speed)==false) {
      this.y = this.y-this.speed; }
    if (this.dir==2) {
      if (this.collision(this.x-this.speed,this.y)==false) {
      this.x = this.x-this.speed; } }
    if (this.dir==3)
      if (this.collision(this.x+this.speed,this.y)==false) {
      this.x = this.x+this.speed; }
    if (this.dir==4) 
      if (this.collision(this.x,this.y+this.speed)==false) {
      this.y = this.y+this.speed;} }
  
  this.collision = function(x,y) {
    
    for (i=0;i<lines.length;i++) {
      var yapple1 = lines[i].y1-(linew/2)-(this.d/2) // up
      var yapple2 = lines[i].y1+(linew/2)+(this.d/2) // down
      var xapple1 = lines[i].x1-(linew/2)-(this.d/2) // right
      var xapple2 = lines[i].x1+(linew/2)+(this.d/2) // left
      // if (this.xl>=lines[i].x1&&this.xl<=lines[i].x2&&this.yl>=lines[i].y1&&this.yl<=lines[i].y2)
      //   this.dir=0;
      if (x>=lines[i].x1&&x<=lines[i].x2&&y>=yapple1&&y<=yapple2) { // horizontal line collision
        return true; }
      if (y>=lines[i].y1&&y<=lines[i].y2&&x>=xapple1&&x<=xapple2) { // vertical line collision
        return true; } }
    return false; }
  }